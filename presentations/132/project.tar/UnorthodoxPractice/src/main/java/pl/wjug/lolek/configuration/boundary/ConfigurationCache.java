/*
 */
package pl.wjug.lolek.configuration.boundary;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import javax.ejb.Startup;

/**
 *
 * @author adam-bien.com
 */
@Startup
@Singleton
public class ConfigurationCache {

    @PostConstruct
    public void preload() {

    }
}
