package pl.wjug.lolek.registration;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("resource")
public class RESTConfiguration extends Application {

}
