package pl.wjug.lolek.registration.boundary;

import javax.ejb.Stateless;
import javax.enterprise.inject.Instance;
import javax.inject.Inject;
import pl.wjug.lolek.registration.control.NameValidator;

@Stateless
public class RegistrationService {

    @Inject
    NameValidator nameValidator;

    @Inject
    Instance<String> host;

    public void register(String name) {
        for (String string : host) {

        }
        System.out.println("Registered: " + name + " with " + host.get());
    }
}
