/*
 */
package pl.wjug.lolek.registration.boundary;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.json.Json;
import javax.json.JsonObject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

@Stateless
@Path("registrations")
public class RegistrationsResource {

    @Inject
    RegistrationService rs;

    @GET
    public JsonObject registrations() {
        return Json.createObjectBuilder().add("name", "duke").add("something", "new").add("age", 42).build();
    }

    @POST
    public void register(JsonObject object) {
        rs.register(object.getString("name"));
    }
}
