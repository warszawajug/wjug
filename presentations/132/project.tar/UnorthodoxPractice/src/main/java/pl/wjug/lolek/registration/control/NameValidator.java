/*
 */
package pl.wjug.lolek.registration.control;

/**
 *
 * @author adam-bien.com
 */
public class NameValidator {

    public boolean check(String name) {
        return "duke".equals(name);
    }
}
