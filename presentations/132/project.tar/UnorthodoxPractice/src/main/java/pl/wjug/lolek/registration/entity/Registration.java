package pl.wjug.lolek.registration.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement
public class Registration {

    private String name;
    private int age;

    public Registration() {
    }

    public Registration(String name, int age) {
        this.name = name;
        this.age = age;
    }

}
